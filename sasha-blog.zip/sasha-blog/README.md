
```

```
Install Dependencies 

```
pip install -r requirements.txt
```


```
python manage.py makemigrations
python manage.py migrate
```
Create SuperUser 
```
python manage.py createsuperuser
```

